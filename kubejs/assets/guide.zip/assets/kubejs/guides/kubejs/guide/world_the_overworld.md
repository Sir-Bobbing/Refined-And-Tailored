
---
# The Overworld
The Surface, ancient and forgotten by the present.

---
## 

## Generation
The Overworld is full of treasures and sights to see. Most of what you may find is covered in the [prospecting](world_prospecting.md) page

---
### Geodes
Existing underground, these hidden treasures can provide a renewable source of materials*

*note: save for the nephrite geode*
| Amethyst | Quartz | Nephrite |
|----------|--------|----------|

<Row>  
<GameScene zoom=".75" interactive={true}>  <ImportStructure src="amethyst_geode.nbt" /><IsometricCamera yaw="45" pitch="30"/></GameScene>
<GameScene zoom=".75" interactive={true}>  <ImportStructure src="quartz_geode_1.nbt" /></GameScene>
<GameScene zoom="1.25" interactive={true}>  <ImportStructure src="nephrite_geode.nbt" /><IsometricCamera yaw="45" pitch="30"/></GameScene>
</Row>
### Hot Springs
On its own it doesn't do much but provide a nice place for you to relax and heal.
Entering its waters will provide you **Regeneration 1**. Additionally has some [slucing](industrial_sluice.md) opportunities.
<GameScene zoom=".65" interactive={true}>  <ImportStructure src="spring_1.nbt" /><IsometricCamera yaw="-45" pitch="30"/></GameScene>
---
