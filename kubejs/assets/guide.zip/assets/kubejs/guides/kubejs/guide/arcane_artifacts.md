---
navigation:
  title: 'Baubles & Trinkets'
  icon: artifacts:cross_necklace
  parent: arcane.md
  position: 4
---
# Baubles & Trinkets
Artifacts and curios, most of which beyond modern ability to reproduce. 

Either hidden away in a cupboard somewhere or within the depths of a mimic. 
These trinkets are valuable to have on hand

---
## Artifacts
Artifacts can be either found within random loot tables, or dropped from a mimic

which looks much like this Chest here
<GameScene zoom={4}>    
<Block id="minecraft:chest" />
<IsometricCamera yaw="-135" pitch="30" />
</GameScene>
The best way to find mimics is through exploring the underground, and coming across
small camps underground. These camps usually have a few workstations, barrels and chests with a campfire in the center, not easy to miss.