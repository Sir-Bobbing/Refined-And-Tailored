---
navigation:
  title: Getting Started
  icon: spelunkery:magnetic_compass
  position: 2
  parent: world.md

---
# Getting Started

Figuring out things on one's own can be fill with frustration and confusion. It is where manual's like this can come in handy.

---

# Changes
#### Ores
- Ores are no longer found everywhere throughout the overworld, refer to the [prospecting chapter](world_prospecting.md) for more information.
---
#### Day-Night cycle 
- The day-night cycle has been altered. being 40 minutes instead of the usual 20 minutes.
---
#### Sleeping
- You must have a light source near your bed in order to not be attacked in your sleep.
- To start sleeping, press <KeyBind id="key.jump" />.
- Sleeping in the same bed grants benefits.
---
#### Inventory 
- Item stack sizes have been adjusted.
- Most Items stack to **256**.
- Potions stack to **16**.
- Vanilla Unstackables are the same.
---
#### Taking Damage
- If you get hit by a mob or other source of damage (fire or poison not included). trying to eat or use a potion will get interrupted
---
#### Tree Chopping 
- When chopping trees down, layers of the log will be taken off a layer at a time. 
- More blocks will have layers stripped depending on the size of the tree.
- When enough layers have been stripped down the entire tree will be felled.
- Can be toggled with a keybind or temporarily stopped with <KeyBind id="key.sneak" />.
---
#### Dying 
- When you die. A corpse holding your inventory will spawn in your place
- The Corpse does **NOT** burn in lava, fall into the void or despawn

  *note: it will only despawn when its inventory has been emptied!*
---
#### Clutter No More
- Most blocks and overlapping furniture options have been combined together using **Clutter No More**.
- Use **\[LEFT ALT]** by default on a valid block will bring up its selection bar.
- Use the Scroll Wheel to cycle.
- Works in the inventory too.

---
# Tools

#### Copper Tools 
A new stage of tools before iron, **Copper Tools & Armor**.
Handy in case you can't find any iron deposits anywhere.

<ItemGrid>  
<ItemIcon id='copper_tools_armor_backport:copper_helmet'/> 
<ItemIcon id='copper_tools_armor_backport:copper_chestplate'/> 
<ItemIcon id='copper_tools_armor_backport:copper_leggings'/> 
<ItemIcon id='copper_tools_armor_backport:copper_boots'/> 
<ItemIcon id='copper_tools_armor_backport:copper_sword'/> 
<ItemIcon id='copper_tools_armor_backport:copper_pickaxe'/> 
<ItemIcon id='copper_tools_armor_backport:copper_axe'/> 
<ItemIcon id='copper_tools_armor_backport:copper_shovel'/> 
<ItemIcon id='copper_tools_armor_backport:copper_hoe'/> 
<ItemIcon id='prospectingpicks:copper_prospector_pick'/> 
</ItemGrid>  
---
#### Bandages 
a cheap way to heal using string.

 <Recipe id="nomansland:bandage" />
 
 As a bonus, Bandages can be upgraded into various types.
 
 **Medicinal:**
 removes any negative potion effect but poison
 <Recipe id="nomansland:medicinal_bandage" />
 **Antidote:**
 removes the poison effect
 <Recipe id="nomansland:antidote_bandage" />
 **Warding:** Grants Absorption for two minutes
 <Recipe id="nomansland:warding_bandage" />

*note: can be used while taking damage*

 ---
#### The Atlas 
Opened with the **\[M]** key by default. The atlas shows an approximation on where you are in the world. With this you can set waypoints, see other players (I think!), the location of airships and vehicles.
![atlas](atlas.png)

As a bonus, if you rename a **Book** <ItemImage id="minecraft:book" scale="0.5"/> in an **Anvil** <ItemImage id="minecraft:anvil" scale="0.5"/> with the name **"Antique Atlas"**.
It will give you an atlas Item.

---
#### Backpack, Bundles & Sacks
Your inventory can still get clogged up with a bunch of unique items, even with the increased Stack size. Meaning 
- **Bundles**<ItemImage id="minecraft:bundle" scale="0.5"/> can be handy. you can use the scroll wheel to control what item you want to remove.
- **Sacks** <ItemImage id="supplementaries:sack" scale="0.5"/> act like an early game shulker. Had up to twelve slots.
- **Backpack** <ItemImage id="reliable_backpacks:backpack" scale="0.5"/> goes into either your chest curio slot or your normal chestplate slot. has 27 slots.
access it by using  <KeyBind id="key.sneak" /> +  <KeyBind id="key.use" />. You can pick it back up by doing the same.

<Row>
 <RecipeFor id="minecraft:bundle" />
 <Recipe id="supplementaries:sack" />
 <RecipeFor id="reliable_backpacks:backpack" />
</Row>
*note: the backpack can be dyed any color.*

*note: shulkers and sacks can't be placed into a backpack, but bundles can.*

#### Spyglass
- use it if you want to zoom
---
# Other

#### Leather
As an early game means to get **Leather**<ItemImage id="minecraft:leather" scale="0.5"/>
you can boil a **Water Bucket**<ItemImage id="minecraft:water_bucket" scale="0.5"/> in a **Furnace**<ItemImage id="minecraft:furnace" scale="0.5"/> to get a **Salt Bucket**<ItemImage id="spelunkery:salt_bucket" scale="0.5"/>

 <Recipe id="spelunkery:leather" />
 ---