---
navigation: 
  title: 'Chunk Loading'
  icon: chunkloaders:advanced_chunk_loader
  parent: industrial.md
  position: 3
---
# Chunk loaders

Invented by Philester Chunk during the industrial golden age after the discovery that trees infact do not make a sound if nobody is around.

This lead Philester to create the 'Loader', a mechanism made to ensure machines remain operational in the absence of people.

---
Chunk loaders are useful tools to keep your farms and factories loaded while you're away.

However do be aware that if you're offline for more than __seven days__. The chunk loaders will automatically turn off. Though once you log back on they'll restart.

<Row>
 <Recipe id="chunkloaders:basic_chunk_loader" />
 <RecipeFor id="chunkloaders:advanced_chunk_loader" />
 <RecipeFor id="chunkloaders:ultimate_chunk_loader" />
 </Row>

### Jarred Chunk loader

Chunkloaders can't be placed on physics contraptions, but in order to ensure your contraptions remain loaded outside of loaded chunks. 
You can simply put an **Advanced Chunk Loader**<ItemImage id='chunkloaders:advanced_chunk_loader' scale="0.5"/> into a **Jar**<ItemImage id='supplementaries:jar' scale="0.5"/>