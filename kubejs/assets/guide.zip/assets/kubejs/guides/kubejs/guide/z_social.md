---
navigation:
  title: Social Features
  icon: minecraft:cake
  position: 10
categories:
  - Other Resources
---
# Social Features

---
## Emojis
- Both style of emojis make use of the double colon naming system like this **:example:**
- Doing **/figura** emojis will show you what Figura emojis are available.
- Doing **:unicode-:** will show all of the available unicode emojis.
----
## Models
Both mods allow for player model customization but do so in different ways.

It's viable to check the keybinds for both mods to get an idea on how to control them.
#### [Figura](https://docs.figuramc.org/)
- More Powerful than CPM, but trickier to use
- Settings in the ESC menu
#### [Customizable Player Models](https://github.com/tom5454/CustomPlayerModels/wiki)
- Easier to use but has limitations
- Settings located in the Skin Editor, which is found in the skin customization options, or in the models tab of the gestures menu
---
## Cosmetic Armor
- In the bottom right of the paper doll in your inventory. there is a small chestplate. clicking on it opens up the cosmetic armor menu.
- In there you can place in an armor to display, or even disable the armor on your playermodel if you want your skin to be shown.
- Doing /coshat will place the item in your hand in the cosmetic head slot.